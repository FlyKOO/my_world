return {
  ["workshop-1207269058"]={ configuration_options={  }, enabled=true },
  ["workshop-1892210190"]={
    configuration_options={ AmiyaLanguage="auto", AmiyaRecipeMode="normal" },
    enabled=true 
  },
  ["workshop-347079953"]={
    configuration_options={ DFV_Language="EN", DFV_MinimalMode="default" },
    enabled=true 
  },
  ["workshop-378160973"]={
    configuration_options={
      ENABLEPINGS=true,
      FIREOPTIONS=2,
      OVERRIDEMODE=false,
      SHAREMINIMAPPROGRESS=true,
      SHOWFIREICONS=true,
      SHOWPLAYERICONS=true,
      SHOWPLAYERSOPTIONS=2 
    },
    enabled=true 
  } 
}